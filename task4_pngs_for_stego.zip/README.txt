Recovered PNGs for Task 4 image/steganography analysis.

Original files: img_0412.png (799x449 RGB), img_0418.png (575x427 RGB).
Embedded files: img_0412_embedded.png (128x128 RGB), img_0418_embedded.png (128x128 RGB).
Embedded PNGs extracted from the thMb PNG chunks and are NOT identical.
None of these four PNGs has an alpha channel in the source file.
The img_0412 original includes additional 228-byte DER material AFTER the embedded PNG inside its thMb chunk.
Do not re-save the original PNGs in an editor before further forensic checks.
Use zsteg -a on each separate PNG to examine possible pixel steganography.
A successful hidden-data claim needs validated format, parse, CRC, or authenticated decryption.
